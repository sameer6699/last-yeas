package com.example.sai.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AfterClickProduct extends AppCompatActivity {

    EditText e1;
    TextView v1,v2,v3,v4;
    Button b1,b2,b3,b4;
    String ina="";
    int q,r,a;
    String adc="";


    InputStream is = null;
    String line = "";
    String result = null;
    String[] data;
    String iurl = "";
    String mdscr ,rate;
    ImageView img;
    Bitmap bitmap;
    ProgressDialog pDialog;
    String s2="";
    String mbno,tbn,pun="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_click_product);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
try
{
        e1=(EditText)findViewById(R.id.txtqty);
        v1=(TextView)findViewById(R.id.tvamt);
        v2=(TextView)findViewById(R.id.tv1);

        v3=(TextView)findViewById(R.id.tvdesc);
        v4=(TextView)findViewById(R.id.tvprice);


        b1=(Button)findViewById(R.id.butplus);
        b2=(Button)findViewById(R.id.butninus);
    b3=(Button)findViewById(R.id.Addc);
    b4=(Button)findViewById(R.id.payment);


        Intent i=getIntent();
        Bundle b=i.getExtras();
        ina=b.getString("iname");
    pun=b.getString("uname");
    s2=b.getString("sname");

        Toast.makeText(this,"Collect shop name "+ s2,Toast.LENGTH_LONG).show();
        v2.setText(ina);
        img = (ImageView) findViewById(R.id.image1);
        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));


        getdata(ina);


        v3.setText(v3.getText()+"\n"+mdscr);
        v4.setText(rate);

        q = Integer.parseInt(e1.getText().toString());
        r = Integer.parseInt(v4.getText().toString());
        a = q * r;
        v1.setText("" + a);


        GetXMLTask task = new GetXMLTask();
        // Execute the task
        task.execute(new String[]{iurl});

    }
        catch (Exception e)
    {
        Toast.makeText(this ,"test error  "+ e.getMessage(),Toast.LENGTH_LONG).show();


    }

}


    private void getdata(String x) {
        try {

            String ht = "?iname=" + URLEncoder.encode(x, "UTF-8").toString();
            //http://ourproject.in/propdeal/getiname.php?iname=Classmate%20notebook%20100%20pages
            String link = "http://aturdoor.co.in/testa/getiname.php" + ht;

            URL url = new URL(link);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            is = new BufferedInputStream(con.getInputStream());
        } catch (Exception e) {
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");

            }
            is.close();
            result = sb.toString();

        } catch (Exception e) {
        }

        try {
            if (result != null) {
                JSONArray ja = new JSONArray(result);
                JSONObject jo = null;
                data = new String[ja.length()];
                for (int i = 0; i < ja.length(); i++) {
                    jo = ja.getJSONObject(i);
                    iurl = jo.getString("ipic");
                    mdscr = jo.getString("idesc");
                    rate = jo.getString("iprice");

                }
            } else {
                Toast.makeText(this, "No Data Found", Toast.LENGTH_LONG).show();

            }
        } catch (Exception e) {
        }

    }

    private class GetXMLTask extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }

        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
            img.setImageBitmap(result);
        }

        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;

            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }

        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();

            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();

                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }


    public void onminusclick(View v)
    {
        int q = Integer.parseInt(e1.getText().toString());

        if(q<=0)
        {
            Toast.makeText(this,"Invalid Quantity ",Toast.LENGTH_LONG).show();
            e1.requestFocus();
            return;
        }
       else {


            q = q - 1;
            e1.setText("" + q);
            int p = Integer.parseInt(v4.getText().toString());

            int t = p * q;
            v1.setText("" + t);

        }
    }

    public void onplusclick(View v)
    {

        if(q<=0)
        {
            Toast.makeText(this,"Invalid Quantity ",Toast.LENGTH_LONG).show();
            e1.requestFocus();
            return;
        }
        else {

            int q = Integer.parseInt(e1.getText().toString());
            q = q + 1;
            e1.setText("" + q);
            int p = Integer.parseInt(v4.getText().toString());

            int t = p * q;
            v1.setText("" + t);

        }

    }


    public void onAddc(View v) {
        // yaha se code shuru karna hai
        new SubmitOrder(this).execute(pun,ina,e1.getText().toString(),rate,v1.getText().toString());

    }

    public void onPayment(View v) {

        Intent pay =new Intent(this,PaymentActivity.class);
        pay.putExtra("uname",pun);
        pay.putExtra("sname",s2);

startActivity(pay);
    }



}

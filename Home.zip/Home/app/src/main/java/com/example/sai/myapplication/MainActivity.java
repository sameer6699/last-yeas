package com.example.sai.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {


    TextView v1,v2;

    EditText e1,e2;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        v1=(TextView)findViewById(R.id.regid);
        v2=(TextView)findViewById(R.id.tvfp);

        e1=(EditText)findViewById(R.id.txtlmobile);
        e2=(EditText)findViewById(R.id.txtlpass);
        b1=(Button)findViewById(R.id.butlog);




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.abtus) {

            Intent abt=new Intent(this,Contactus.class);
            startActivity(abt);

        }

        return super.onOptionsItemSelected(item);
    }

    public void rclick(View v)
    {
        Intent reg=new Intent(this,UserRegister.class);
        startActivity(reg);

   }

    public void fpsclick(View v)
    {
        Intent fgps=new Intent(this,ForgetPassword.class);
        startActivity(fgps);
    }



    public void logclick(View v)
    {
        String s1,s2;
        s1=e1.getText().toString();
        s2=e2.getText().toString();

        if(s1.equals(""))
        {
            Toast.makeText(this,"Plz Enter Mobile No  ",Toast.LENGTH_LONG).show();
            e1.requestFocus();
            return;
        }
        if(s2.equals("") )
        {
            Toast.makeText(this,"Plz Enter Valid Password   ",Toast.LENGTH_LONG).show();
            e2.requestFocus();
            return;
        }

        Toast.makeText(this,"Plz Wait User Login Here .....",Toast.LENGTH_LONG).show();
        new lcheckActivity(this).execute(s1,s2);


    }

}

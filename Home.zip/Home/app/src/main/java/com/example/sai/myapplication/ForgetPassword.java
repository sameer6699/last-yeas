package com.example.sai.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ForgetPassword extends AppCompatActivity {

    EditText e1,e2;
    Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        e1=(EditText)findViewById(R.id.txtfmobile);
        e2=(EditText)findViewById(R.id.txtfemail);
        b1=(Button)findViewById(R.id.butfget);

    }

    public void onfget(View v)
    {

        String s1,s2;
        s1=e1.getText().toString();
        s2=e2.getText().toString();
        if(s1.equals("") || s1.length()<=9 )
        {
            Toast.makeText(this,"Plz Enter Valid Mobile no ",Toast.LENGTH_LONG).show();
            e1.requestFocus();
            return;

        }
        if(s2.trim().equals("")  )
        {
            Toast.makeText(this,"Plz Enter Valid Email Id  ",Toast.LENGTH_LONG).show();
            e1.requestFocus();
            return;
        }

        Toast.makeText(this,"Plz Wait ",Toast.LENGTH_LONG).show();
        new PassCheck(this).execute(s1,s2);


    }

}

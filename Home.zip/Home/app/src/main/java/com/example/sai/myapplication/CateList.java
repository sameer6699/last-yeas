package com.example.sai.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class CateList extends AppCompatActivity {

    TextView v1;

    ListView lv;
    ArrayAdapter<String> adapter;
    InputStream is = null;
    String line = "";
    String result = null;
    String[] data;
    String h="";
    String pun;
    String hpname="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cate_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        v1=(TextView)findViewById(R.id.cv1);
        Intent i=getIntent();
        Bundle b=i.getExtras();
        h=b.getString("cname");
        pun=b.getString("uname");
        v1.setText("Ur Selection is:- "+h);


        lv = (ListView) findViewById(R.id.list);
        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
        getdata();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // When clicked, show a toast with the TextView text
                Toast.makeText(getApplicationContext(),"U Select Shop  Name "+ ((TextView) view).getText(), Toast.LENGTH_SHORT).show();
                Intent sn=new Intent(getApplicationContext(),Shopdetail.class);
                sn.putExtra("sname",((TextView) view).getText().toString().trim());
                sn.putExtra("uname",pun);
                //slh.putExtra("uname",pun);
                startActivity(sn);
            }
        });


    }

    private void getdata() {
        try {

            String ht="?category="+URLEncoder.encode(h,"UTF-8").toString();
            String link = "http://aturdoor.co.in/testa/getsname.php"+ht;

            URL url = new URL(link);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            is = new BufferedInputStream(con.getInputStream());
        } catch (Exception e) {
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            while ((line=br.readLine()) != null)
            {
                sb.append(line + "\n");

            }
            is.close();
            result = sb.toString();

        } catch (Exception e) {
        }

        try {
            if(result!=null)
            {
                JSONArray ja = new JSONArray(result);
                JSONObject jo = null;
                data = new String[ja.length()];
                for (int i = 0; i < ja.length(); i++) {
                    jo = ja.getJSONObject(i);
                    data[i] = jo.getString("sname");
                    //hpname=jo.getString("hname");
                    //+"\n"+jo.getString("address")+"\n"+jo.getString("drname")+"\n"+jo.getString("contact")
                }}
            else
            {
                Toast.makeText(this ,"No Data Found",Toast.LENGTH_LONG).show();

            }
        } catch (Exception e) {
        }

    }

}

package com.example.sai.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class getOtpActivity extends AppCompatActivity {

    String un;

    EditText e1;
    CheckBox chap;
    Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_otp);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent i = getIntent();
        Bundle b = i.getExtras();
        un = b.getString("uname");
        Toast.makeText(this,"Hi "+un,Toast.LENGTH_LONG).show();
        e1=(EditText)findViewById(R.id.txtotp);
        chap=(CheckBox)findViewById(R.id.chatc);
        b1=(Button)findViewById(R.id.butsotp);


    }


    public void submitotp(View v)
    {

        if(e1.getText().toString().trim().equals(""))
        {
            Toast.makeText(this,"Plz Enter OTP ",Toast.LENGTH_LONG).show();
            e1.requestFocus();
            return;


        }


        if(chap.isChecked()==false)
        {
            Toast.makeText(this,"Plz Select Apply Term & Condition ",Toast.LENGTH_LONG).show();
            return;

        }

        Toast.makeText(this,"Plz  Wait Ur OTP Is Submit   ",Toast.LENGTH_LONG).show();

        String sotp=e1.getText().toString();
        new ConfirmOTP(this).execute(un,sotp);

    }



}

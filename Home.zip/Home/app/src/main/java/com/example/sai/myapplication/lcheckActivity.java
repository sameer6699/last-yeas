package com.example.sai.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class lcheckActivity extends AsyncTask<String,Void,String> {

    private Context ctx;
    String mb="",pun="";

    public lcheckActivity(Context context){
        this.ctx=context;
    }
    @Override
    protected String doInBackground(String... strings) {
         mb = strings[0];
        pun=mb.toString();
        String ps = strings[1];

        String link;
        String data;
        BufferedReader bufferedReader;
        String result;
        try {
            data = "?mobile=" + URLEncoder.encode(mb, "UTF-8");
            data += "&upass=" + URLEncoder.encode(ps, "UTF-8");

           // http://aturdoor.co.in/api/lgcheck.php?mobile=9422448367&upass=sir
           // http://aturdoor.co.in/testa/lgcheck.php?mobile=9422448367&upass=sir
            link = "http://aturdoor.co.in/testa/lgcheck.php" + data;
            URL url = new URL(link);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            result = bufferedReader.readLine();
            return result;
        } catch (Exception e) {
            return new String("Exception" + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String result) {
        String jsonStr=result;
        if(jsonStr!=null){
            try
            {
                JSONObject jsonObj=new JSONObject(jsonStr);
                String query_result=(String)jsonObj.getString("query_result");
                if(query_result.equals("SUCCESS"))
                {
                    Toast.makeText(ctx ,"login is successfull "+pun,Toast.LENGTH_LONG).show();
                   ctx.startActivity(new Intent(ctx, AFterLog.class).putExtra("uname",pun));

                }
                else  if(query_result.equals("FAILURE"))
                {
                    Toast.makeText(ctx,"Wrong Password",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(ctx,"Internet Issue",Toast.LENGTH_LONG).show();
                }
            }
            catch (JSONException e)
            {
                Toast.makeText(ctx,"error "+ result.toString()+" bhoot ",Toast.LENGTH_LONG).show();
            }
        }
        //super.onPostExecute(s);
        else
        {
            Toast.makeText(ctx,"error parsing json data",Toast.LENGTH_LONG).show();
        }
    }

}

package com.example.sai.myapplication;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;

public class PaymentActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    android.app.AlertDialog.Builder builder;
    android.app.AlertDialog Alert;

    String un,s2;

    ListView lv;
    Button conf;

    TextView v1, v2, v3;
    ArrayAdapter<String> adapter;
    InputStream is = null;
    String line = "";
    String result = null;
    String[] data;
    String[] tempdata;
    int tot = 0;


    String hpname, pun;

    List<RowItem> rowItems;

    String mbno, tbn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        try {


            Intent i = getIntent();
            Bundle b = i.getExtras();
            un = b.getString("uname");
            s2 = b.getString("sname");

            Toast.makeText(this, "Dear shop name " + s2, Toast.LENGTH_LONG).show();

            v1 = (TextView) findViewById(R.id.tvamt);
            v2 = (TextView) findViewById(R.id.tvgst);
            v3 = (TextView) findViewById(R.id.tvnet);


            conf = (Button) findViewById(R.id.confirm);
            lv = (ListView) findViewById(R.id.list);
            StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
            getdata(un);

            rowItems = new ArrayList<RowItem>();
            for (int k = 0; k < data.length; k++) {
                RowItem item = new RowItem(data[k]);
                rowItems.add(item);
            }
            v1.setText("Total Amount is :- " + tot);
            int gst = tot * 10 / 100;
            v2.setText(v2.getText() + " " + gst);
            int net = tot + gst;
            v3.setText(v3.getText() + " " + net);
            CustomBaseAdapter adapter = new CustomBaseAdapter(this, rowItems);

            //adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data);
            lv.setAdapter(adapter);
            lv.setOnItemClickListener(this);


        } catch (Exception e) {
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }


    public void confClick(View v) {



        builder=new android.app.AlertDialog.Builder(this);
        builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setTitle("Confirm");
        builder.setMessage("Do you Want Continue? ");
        builder.setCancelable(false);
        builder = new android.app.AlertDialog.Builder(this, R.style.MyDialogTheme);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

            ProgressDialog loading;
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {


                try {
                    //String t = s1.substring(s1.length() - 3);


                    //Toast.makeText(PaymentActivity.this, "mobno "+mbno+" "+"total "+s1+" "+e1.getText().toString()+" "+tbn, Toast.LENGTH_LONG).show();
                    //new submitFinal(SuccessActivity.this).execute(mbno, t, e1.getText().toString(), tbn);

                    Intent acc = new Intent(PaymentActivity.this,  AfterConfirmClick .class);
                    acc.putExtra("uname", un);
                    acc.putExtra("total", String.valueOf(tot));
                    acc.putExtra("sname", s2);


                    startActivity(acc);


                }
                catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(), "test error "+ e.getMessage(), Toast.LENGTH_LONG).show();

                }
            }
        });



        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {

            ProgressDialog loading;
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {


                Intent geto=new Intent(PaymentActivity.this,PaymentActivity.class);

            }
        });



        Alert= builder.create();
        Alert.show();




    }

    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        final String mn = rowItems.get(position).toString();
        String[] words = mn.split(":");
        final String psn = words[0];
        Toast toast = Toast.makeText(PaymentActivity.this,
                "You have selected  " + rowItems.get(position),
                Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.show();
        PopupMenu popup = new PopupMenu(this, lv);

        popup.inflate(R.menu.options_menu);


        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.menu1:
                        Toast.makeText(PaymentActivity.this, "delete  " + psn, Toast.LENGTH_LONG).show();

                        new delOrder(PaymentActivity.this).execute(un,psn);

                        break;


                }
                return false;
            }
        });
        //displaying the popup

        popup.show();

    }

    private void getdata(String x) {
        try {

            String s1 = "?usernm=" + x;
//http://ourproject.in/propdeal/getorder.php?usernm=9422448367
            String link = "http://aturdoor.co.in/testa/getorder.php" + s1;
            URL url = new URL(link);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            is = new BufferedInputStream(con.getInputStream());
        } catch (Exception e) {
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");

            }
            is.close();
            result = sb.toString();

        } catch (Exception e) {
        }

        try {
            if (result != null) {
                JSONArray ja = new JSONArray(result);
                JSONObject jo = null;
                data = new String[ja.length()];
                for (int i = 0; i < ja.length(); i++) {
                    jo = ja.getJSONObject(i);
                    data[i] = jo.getString("pname") + ":" + "  " + jo.getString("qty") + " " + jo.getString("rate") + " " + jo.getString("amount");
                    // tempdata[i] = jo.getString("mname");
                    tot = tot + Integer.parseInt(jo.getString("amount"));


                }
            } else {
                Toast.makeText(this, "No Data Found", Toast.LENGTH_LONG).show();

            }

        } catch (Exception e) {
        }

    }
}

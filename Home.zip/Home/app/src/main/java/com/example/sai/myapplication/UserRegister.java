package com.example.sai.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class UserRegister extends AppCompatActivity {
EditText e1,e2,e3,e4,e5,e6;
Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        e1=(EditText)findViewById(R.id.txtfname);
        e2=(EditText)findViewById(R.id.txtmobile);
        e3=(EditText)findViewById(R.id.txtemail);
        e4=(EditText)findViewById(R.id.txtupass);
        e5=(EditText)findViewById(R.id.txtadd);
        e6=(EditText)findViewById(R.id.txtpcode);
        b1=(Button)findViewById(R.id.butreg);


    }


    public void onreg(View v)
    {
        String s1,s2,s3,s4,s5,s6;
        s1=e1.getText().toString();
        s2=e2.getText().toString();
        s3=e3.getText().toString();
        s4=e4.getText().toString();
        s5=e5.getText().toString();
        s6=e6.getText().toString();

        if(s1.equals(""))
        {
            Toast.makeText(this,"Plz Enter Full Name ",Toast.LENGTH_LONG).show();
            e1.requestFocus();
            return;
        }
        if(s2.equals("") && s1.length()<=9)
        {
            Toast.makeText(this,"Plz Enter Mobile Valid mobileno   ",Toast.LENGTH_LONG).show();
            e2.requestFocus();
            return;
        }
        if(s3.trim().equals(""))
        {
            Toast.makeText(this,"Plz Enter Valid Email ID ",Toast.LENGTH_LONG).show();
            e3.requestFocus();
            return;
        }
        if(s4.trim().equals(""))
        {
            Toast.makeText(this,"Plz Enter Valid Password ",Toast.LENGTH_LONG).show();
            e4.requestFocus();
            return;
        }
        if(s5.trim().equals(""))
        {
            Toast.makeText(this,"Plz Enter Valid Address ",Toast.LENGTH_LONG).show();
            e5.requestFocus();
            return;
        }
        if(s6.trim().equals("") && s6.trim().length()<6)
        {
            Toast.makeText(this,"Plz Enter Valid Pincode ",Toast.LENGTH_LONG).show();
            e6.requestFocus();
            return;
        }

        Toast.makeText(this,"Plz Wait User Register .....",Toast.LENGTH_LONG).show();
        new RegiserActivity(this).execute(s1,s2,s3,s4,s5,s6);
    }

}

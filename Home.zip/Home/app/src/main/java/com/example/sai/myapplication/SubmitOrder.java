package com.example.sai.myapplication;

import android.content.Context;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.os.AsyncTask;
import android.os.Build;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;

import androidx.annotation.RequiresApi;

public class SubmitOrder extends AsyncTask<String,Void,String> {
    private Context ctx;

    String pun;
    public SubmitOrder(Context context){
        this.ctx=context;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected String doInBackground(String... strings) {
        String un = strings[0];
pun=un;
        String pn = strings[1];
        String qt = strings[2];
        String rt = strings[3];
        String am = strings[4];
        String link;
        String data;
        BufferedReader bufferedReader;
        String result;

        DateFormat dateFormat=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String sd=dateFormat.format(date).toString();


        try {

            data = "?usernm=" + URLEncoder.encode(un, "UTF-8");
            data += "&pname=" + URLEncoder.encode(pn, "UTF-8");
            data += "&qty=" + URLEncoder.encode(qt, "UTF-8");
            data += "&rate=" + URLEncoder.encode(rt, "UTF-8");
            data += "&amount=" + URLEncoder.encode(am, "UTF-8");


            http://ourproject.in/propdeal/insertorder.php?usernm=7987&pname=lux&qty=100&rate=888&amount=9999


            link = "http://aturdoor.co.in/testa/insertorder.php" + data;
            URL url = new URL(link);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            result = bufferedReader.readLine();
            return result;
        } catch (Exception e) {
            return new String("Exception" + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String result) {
        String jsonStr=result;
        if(jsonStr!=null){
            try
            {
                JSONObject jsonObj=new JSONObject(jsonStr);
                String query_result=jsonObj.getString("query_result");
                if(query_result.equals("SUCCESS"))
                {
                    Toast.makeText(ctx ,"Product Add  Succesfuly  In Cart "+pun ,Toast.LENGTH_LONG).show();
                    //ctx.startActivity(new Intent(ctx, AfterLRActivity.class).putExtra("uname",pun));


                }
                else  if(query_result.equals("FAILURE"))
                {
                    Toast.makeText(ctx,"Data could not be insert",Toast.LENGTH_LONG).show();
                }

                else
                {
                    Toast.makeText(ctx,"not connect with database",Toast.LENGTH_LONG).show();
                }
            }
            catch (JSONException e)
            {
                Toast.makeText(ctx,"not fet any json",Toast.LENGTH_LONG).show();
            }
        }
        //super.onPostExecute(s);
        else
        {
            Toast.makeText(ctx,"error parsing json data",Toast.LENGTH_LONG).show();
        }
    }
}


package com.example.sai.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class submitFinal extends AsyncTask<String,Void,String> {
    private Context ctx;
    String pun;

    public submitFinal(Context context) {
        this.ctx = context;
    }

    @Override
    protected String doInBackground(String... strings) {
        String un = strings[0];
        pun=un;
        String tot = strings[1];
        String sn = strings[2];

        String fn = strings[3];
        String ad = strings[4];
        String ct = strings[5];
        String lm = strings[6];




        String link;
        String data;
        BufferedReader bufferedReader;
        String result;



        try {
            data = "?usernm=" + URLEncoder.encode(un, "UTF-8");
            data += "&totalamount=" + URLEncoder.encode(tot, "UTF-8");
            data += "&sname=" + URLEncoder.encode(sn, "UTF-8");
            data += "&fname=" + URLEncoder.encode(fn, "UTF-8");
            data += "&address=" + URLEncoder.encode(ad, "UTF-8");
            data += "&city=" + URLEncoder.encode(ct, "UTF-8");
            data += "&lmark=" + URLEncoder.encode(lm, "UTF-8");



            //http://ourproject.in/propdeal/insertforder.php?usernm=7987&totalamount=777

            link = "http://aturdoor.co.in/testa/insertforder.php" + data;
            URL url = new URL(link);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            result = bufferedReader.readLine();
            return result;
        } catch (Exception e) {
            return new String("Exception" + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String result) {
        String jsonStr = result;
        if (jsonStr != null) {
            try {
                JSONObject jsonObj = new JSONObject(jsonStr);
                String query_result = jsonObj.getString("query_result");
                if (query_result.equals("SUCCESS")) {
                    Toast.makeText(ctx, "get otp  " , Toast.LENGTH_LONG).show();
                   ctx.startActivity(new Intent(ctx, getOtpActivity.class).putExtra("uname",pun));


                } else if (query_result.equals("FAILURE")) {
                    Toast.makeText(ctx, "Data could not be insert", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(ctx, "not connect with database", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                Toast.makeText(ctx, "not fetch any json", Toast.LENGTH_LONG).show();
            }
        }
        //super.onPostExecute(s);
        else {
            Toast.makeText(ctx, "error parsing json data", Toast.LENGTH_LONG).show();
        }
    }
}
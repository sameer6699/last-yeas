package com.example.sai.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ItemDetail extends AppCompatActivity {

    ListView listView;
    EditText e1;
    private  String newurl = "";
    InputStream is = null;
    String line = "";
    String result = null;
    private String json;
    private JSONArray urls;
    public  Getjson getjsonobj;
    Customadapter customadapter;
    String[] namedata;
    String s2="";
    String mbno,tbn,pun;

    TextView ci;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        listView = (ListView) findViewById(R.id.list);
        ci=(TextView)findViewById(R.id.citem1);
        Intent i=getIntent();
        Bundle b=i.getExtras();
        s2=b.getString("sname");
        pun=b.getString("uname");
        String s1="?sname="+s2;
        Toast.makeText(this,"collect Shop name "+s2,Toast.LENGTH_LONG).show();



//http://ourproject.in/propdeal/getalliname.php?sname=Mundada%20books%20Stall
        newurl = "http://aturdoor.co.in/testa/getalliname.php"+s1;
        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
        getdata(s2);
        getURLs();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick (AdapterView < ? > parent, View view,int position, long id){
                try {
                    // When clicked, show a toast with the TextView text
                    String pass=namedata[position];
                    Toast.makeText(getApplicationContext(), "Your Selected Product  " + pass, Toast.LENGTH_SHORT).show();
                   Intent acmi=new Intent(getApplicationContext(),AfterClickProduct.class);
                    acmi.putExtra("iname",pass);
                    acmi.putExtra("uname",pun);
                    acmi.putExtra("sname",s2);

                    //acmi.putExtra("mob",mbno);
                    //acmi.putExtra("tbn",tbn);
                    // Toast.makeText(StartersActivity.this,"pass table no "+tbn,Toast.LENGTH_LONG).show();
                    //slh.putExtra("uname",pun);
                    startActivity(acmi);
                }
                catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(), "error " + e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }


        });









    }



    //Get imageTYpe
    private void getImages() {
        class GetImages extends AsyncTask<Void, Void, Void> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(ItemDetail.this, "Fetch Information ", "Please wait...", false, false);
            }

            @Override
            protected void onPostExecute(Void v) {
                super.onPostExecute(v);
                loading.dismiss();


                customadapter = new Customadapter(ItemDetail.this, getjsonobj.Android_Name ,getjsonobj.bitmaps, getjsonobj.price_list ,getjsonobj.quantity);

                listView.setAdapter(customadapter);


            }

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    getjsonobj.getAllImages();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return null;
            }
        }
        GetImages getImages = new GetImages();
        getImages.execute();
    }

    private void getURLs() {

        class GetURLs extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(ItemDetail.this, "Loading...", "Please Wait...", true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                getjsonobj = new Getjson(s);
                getImages();
            }

            @Override
            protected String doInBackground(String... strings) {
                BufferedReader bufferedReader = null;
                try {

                    URL url = new URL(strings[0]);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }

                    return sb.toString().trim();

                } catch (Exception e) {
                    return null;

                }
            }
        }
        GetURLs gu = new GetURLs();


        gu.execute(newurl);


    }


    private void getdata(String x) {
        try {


             Toast.makeText(this,"pass type "+x,Toast.LENGTH_LONG).show();
            String s="?sname="+x;
            //http://ourproject.in/propdeal/getallitemname.php?sname=
            String link = "http://aturdoor.co.in/testa/getallitemname.php"+s;
            URL url = new URL(link);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            is = new BufferedInputStream(con.getInputStream());
        } catch (Exception e) {
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            while ((line=br.readLine()) != null)
            {
                sb.append(line + "\n");

            }
            is.close();
            result = sb.toString();

        } catch (Exception e) {
        }

        try {
            JSONArray ja = new JSONArray(result);
            JSONObject jo = null;
            namedata = new String[ja.length()];
            for (int i = 0; i < ja.length(); i++) {
                jo = ja.getJSONObject(i);
                namedata[i] = jo.getString("iname");
                //Toast.makeText(this,"store "+i+"  " +jo.getString("hname"),Toast.LENGTH_LONG ).show();
            }
        } catch (Exception e) {
        }

    }



    public void citemcl(View v)
    {
        Intent pp=new Intent(this,PaymentActivity.class);
        pp.putExtra("uname",pun);
        startActivity(pp);

    }

}
